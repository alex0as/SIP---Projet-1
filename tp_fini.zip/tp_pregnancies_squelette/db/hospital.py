def insert_hospital(code, name):
    """Insert a new hospital into the database."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        query = "INSERT INTO Hospital (code, name) VALUES (?, ?)"
        cursor.execute(query, (code, name))
        conn.commit()
    except sqlite3.IntegrityError as error:
        print(f"Integrity error while inserting hospital: {error}")
        close_db_connexion(cursor, conn)
        return False
    except sqlite3.Error as error:
        print(f"Database error while inserting hospital: {error}")
        close_db_connexion(cursor, conn)
        return False

    close_db_connexion(cursor, conn)
    return True


def get_hospital(hospital_id):
    """Get a hospital by its code or ID."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        query = "SELECT * FROM Hospital WHERE code = ?"
        cursor.execute(query, (hospital_id,))
        hospital = cursor.fetchone()
    except sqlite3.Error as error:
        print(f"Database error while fetching hospital: {error}")
        close_db_connexion(cursor, conn)
        return None

    close_db_connexion(cursor, conn)
    return hospital


def get_hospitals():
    """Get all hospitals from the database."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        query = "SELECT * FROM Hospital"
        cursor.execute(query)
        hospitals = cursor.fetchall()
    except sqlite3.Error as error:
        print(f"Database error while fetching hospitals: {error}")
        close_db_connexion(cursor, conn)
        return None

    close_db_connexion(cursor, conn)
    return hospitals
