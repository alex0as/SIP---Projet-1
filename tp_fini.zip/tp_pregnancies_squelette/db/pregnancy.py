def insert_pregnancy(
    id,
    registration_date, 
    registration_time,
    delivery_date,
    baby_gender,
    delivery_type,
    number_of_checkup_done,
    woman_code,
    analyst_name,
):
    """Insert a pregnancy into the database."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        query = """
        INSERT INTO Pregnancy (
            id, registration_date, registration_time, delivery_date,
            baby_gender, delivery_type, number_of_checkup_done,
            woman_code, analyst_name
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        cursor.execute(query, (
            id,
            registration_date,
            registration_time,
            delivery_date,
            baby_gender,
            delivery_type,
            number_of_checkup_done,
            woman_code,
            analyst_name,
        ))
        conn.commit()
    except sqlite3.IntegrityError as error:
        print(f"Integrity error while inserting pregnancy: {error}")
        close_db_connexion(cursor, conn)
        return False
    except sqlite3.Error as error:
        print(f"Database error while inserting pregnancy: {error}")
        close_db_connexion(cursor, conn)
        return False

    close_db_connexion(cursor, conn)
    return True


def get_pregnancies():
    """Get all pregnancies from the database."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT * FROM Pregnancy")
        pregnancies = cursor.fetchall()
    except sqlite3.Error as error:
        print(f"Database error while fetching pregnancies: {error}")
        close_db_connexion(cursor, conn)
        return None

    close_db_connexion(cursor, conn)
    return pregnancies


def get_pregnancy(id):
    """Get one pregnancy by ID."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT * FROM Pregnancy WHERE id = ?", (id,))
        pregnancy = cursor.fetchone()
    except sqlite3.Error as error:
        print(f"Database error while fetching pregnancy: {error}")
        close_db_connexion(cursor, conn)
        return None

    close_db_connexion(cursor, conn)
    return pregnancy


def get_involved_woman(id):
    """Get the woman involved in a given pregnancy."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        query = """
        SELECT Woman.* FROM Woman
        JOIN Pregnancy ON Woman.code = Pregnancy.woman_code
        WHERE Pregnancy.id = ?
        """
        cursor.execute(query, (id,))
        woman = cursor.fetchone()
    except sqlite3.Error as error:
        print(f"Database error while fetching involved woman: {error}")
        close_db_connexion(cursor, conn)
        return None

    close_db_connexion(cursor, conn)
    return woman


def insert_hospital_pregnancy(id, hospital_id):
    """Associate a pregnancy with a hospital (insert)."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        query = "UPDATE Pregnancy SET hospital_id = ? WHERE id = ?"
        cursor.execute(query, (hospital_id, id))
        conn.commit()
    except sqlite3.Error as error:
        print(f"Database error while inserting hospital pregnancy: {error}")
        close_db_connexion(cursor, conn)
        return False

    close_db_connexion(cursor, conn)
    return True


def update_hospital_pregnancy(id, hospital_id):
    """Update the hospital associated with a pregnancy."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        query = "UPDATE Pregnancy SET hospital_id = ? WHERE id = ?"
        cursor.execute(query, (hospital_id, id))
        conn.commit()
    except sqlite3.Error as error:
        print(f"Database error while updating hospital pregnancy: {error}")
        close_db_connexion(cursor, conn)
        return False

    close_db_connexion(cursor, conn)
    return True


def get_hospital_pregnancy(id, hospital_id):
    """Get all pregnancies for a given hospital."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        query = "SELECT * FROM Pregnancy WHERE hospital_id = ?"
        cursor.execute(query, (hospital_id,))
        pregnancies = cursor.fetchall()
    except sqlite3.Error as error:
        print(f"Database error while getting hospital pregnancies: {error}")
        close_db_connexion(cursor, conn)
        return None

    close_db_connexion(cursor, conn)
    return pregnancies


def update_pregnancy_delivery_type(id, delivery_type):
    """Update the delivery type of a pregnancy."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        query = "UPDATE Pregnancy SET delivery_type = ? WHERE id = ?"
        cursor.execute(query, (delivery_type, id))
        conn.commit()
    except sqlite3.Error as error:
        print(f"Database error while updating delivery type: {error}")
        close_db_connexion(cursor, conn)
        return False

    close_db_connexion(cursor, conn)
    return True


def update_pregnancy_woman(id, woman_id):
    """Update the woman associated with a pregnancy."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        query = "UPDATE Pregnancy SET woman_code = ? WHERE id = ?"
        cursor.execute(query, (woman_id, id))
        conn.commit()
    except sqlite3.Error as error:
        print(f"Database error while updating pregnancy woman: {error}")
        close_db_connexion(cursor, conn)
        return False

    close_db_connexion(cursor, conn)
    return True
