from flask import Blueprint, jsonify

checkups_bp = Blueprint("checkups", __name__)


@checkups_bp.route("/<int:checkup_id>")
def get_checkup(checkup_id):
    """Get a checkup in the database.

    Parameters
    ----------
    checkup_id
        id of the checkup to get

    Returns
    -------
    data
        all data about the checkup if correctly fetched
        a message "checkup does not exist" if the checkup is not found in
            the database.
        an error message "Error: while fetching the checkup" if an error
            occured while fetching the checkup.
    status_code
        200 if the checkup is correctly fetched
        404 if the checkup does not exist in the database
        500 if an error occured while fetching the checkup
    """
    # TODO
    return jsonify({"message": "TODO"})


@checkups_bp.route("/<int:checkup_id>/purchase", methods=["POST"])
def purchase_checkup(checkup_id):
    """Assign a checkup to a pregnancy.
    The fields to update the owner must be passed in the data of the POST request among
    the following (pass all of them):
        - username
        - password

    Parameters
    ----------
    checkup_id
        id of the checkup to get

    Returns
    -------
    data
        a message "Done" if the pregnancy is assigned correctly to the checkup.
        a message "No pregnancy username provided for assignment" if no the field
            username is not found in the request data
        a message "checkup does not exist" if the checkup is not found in
            the database.
        a message "pregnancy does not exist" if the pregnancy is not found in the
            database
        an error message "Error: while fetching the checkup" if an error
            occured while fetching the checkup.
    status_code
        200 if the checkups are correctly fetched
        400 if no the field username is not found in the request data
        404 if the checkup does not exist in the database
        404 if the pregnancy does not exist in the database
        500 if an error occured while fetching the checkup
    """
    # TODO
    return jsonify({"message": "TODO"})
