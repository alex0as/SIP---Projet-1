from flask import Blueprint, request, jsonify

data_bp = Blueprint("data", __name__)


@data_bp.route("/pregnancies")
def get_pregnancies():
    """Get all pregnancies in the database.

    Returns
    -------
    data
        all pregnancies in the database
        an error message "Error: while fetching pregnancies" if an error occured
            while fetching the pregnancies.
    status_code
        200 if the pregnancies are correctly fetched
        500 if an error occured while fetching the pregnancies
    """
    conn = get_db_connexion()
    cursor = conn.cursor()
    
    pregnancies = db.pregnancy.get_pregnancies(cursor)
    if pregnancies is None:
        close_db_connexion(cursor, conn)
        return jsonify({"error": "Error while fetching pregnancies"}), 500

    close_db_connexion(cursor, conn)
    return jsonify({"pregnancies": pregnancies}), 200


@data_bp.route("/hospitals")
def get_hospitals():
    """Get all hospitals in the database.

    Returns
    -------
    data
        all hospitals in the database
        an error message "Error: while fetching hospitals" if an error occured
            while fetching the hospitals.
    status_code
        200 if the hospitals are correctly fetched
        500 if an error occured while fetching the hospitals
    """
    conn = get_db_connexion()
    cursor = conn.cursor()

    hospitals = db.hospital.get_hospitals(cursor)
    if hospitals is None:
        close_db_connexion(cursor, conn)
        return jsonify({"error": "Error while fetching hospitals"}), 500

    close_db_connexion(cursor, conn)
    return jsonify({"hospitals": hospitals}), 200


@data_bp.route("/checkups")
def get_checkups():
    """Get all checkups in the database.

    Returns
    -------
    data
        all checkups in the database
        an error message "Error: while fetching checkups" if an error occured
            while fetching the checkups.
    status_code
        200 if the checkups are correctly fetched
        500 if an error occured while fetching the checkups
    """
    conn = get_db_connexion()
    cursor = conn.cursor()

    checkups = db.checkup.get_checkups(cursor)
    if checkups is None:
        close_db_connexion(cursor, conn)
        return jsonify({"error": "Error while fetching checkups"}), 500

    close_db_connexion(cursor, conn)
    return jsonify({"checkups": checkups}), 200


@data_bp.route("/women")
def get_women():
    """Get all women in the database.

    Returns
    -------
    data
        all women in the database
        an error message "Error: while fetching women" if an error occured
            while fetching the women.
    status_code
        200 if the women are correctly fetched
        500 if an error occured while fetching the women
    """
    conn = get_db_connexion()
    cursor = conn.cursor()

    women = db.woman.get_women(cursor)
    if women is None:
        close_db_connexion(cursor, conn)
        return jsonify({"error": "Error while fetching women"}), 500

    close_db_connexion(cursor, conn)
    return jsonify({"women": women}), 200
