import requests

# L’adresse du serveur Flask
url = "http://localhost:5000/analysts/"

try:
    # Envoie une requête GET à l'API
    response = requests.get(url)

    # Vérifie le code de statut HTTP
    if response.status_code == 200:
        # Si tout va bien, on affiche le JSON renvoyé
        data = response.json()
        print("Requête réussie !")
        print("Liste des analysts :", data["analysts"])
    else:
        print(f"Erreur HTTP {response.status_code}")
        print("Message :", response.text)

except requests.exceptions.ConnectionError:
    print("Impossible de se connecter à l’API. app.py est-il lancé ?")
except Exception as e:
    print("Erreur :", e)
