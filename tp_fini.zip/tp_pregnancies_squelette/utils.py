# import bcrypt
# import jwt
# import datetime
from functools import wraps
from flask import request, jsonify

import db
from db.analysts import get_analyst

CONFIG_FILE = "./config/config"


def load_config():
    """Loads the application configuration from the configuration file
    into a dictionary.

    Returns
    -------
    A dictionary.
        The application configuration.
    """
    config = {}

    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            for line in f:
                # Strip newline and whitespace
                line = line.strip()
                if not line:
                    continue  # Skip empty lines
                # Split on the first comma
                key, value = line.split(",", 1)
                # Remove potential surrounding quotes from value
                value = value.strip().strip('"')
                config[key.strip()] = value
    except FileNotFoundError:
        raise FileNotFoundError(f"Configuration file '{CONFIG_FILE}' not found.")
    except Exception as e:
        raise RuntimeError(f"Error reading configuration file: {e}")

    return config


def hash_password(plain_password):
    """Hash a password

    Parameters
    ----------
    plain_password
        plain password to hash

    Returns
    -------
    hashed_password
        A password hash
    """
    if isinstance(password, str):
        password = password.encode('utf-8')  # convertir en bytes
    hashed = bcrypt.hashpw(password, bcrypt.gensalt())
    return hashed.decode('utf-8')  # stocker en UTF-8 dans la DB


def check_password(plain_password, hashed_password):
    """Check the plain password against its hashed value

    Parameters
    ----------
    plain_password
        the plain password to check
    hashed_password
        a password hash to check if it is the hash of the plain password

    Returns
    -------
    bool
        True if hashed_password is the hash of plain_password, False otherwise
    """
    if isinstance(password, str):
        password = password.encode('utf-8')
    if isinstance(hashed, str):
        hashed = hashed.encode('utf-8')
    return bcrypt.checkpw(password, hashed)


def check_analyst(username, plain_password):
    """Authenticate a analyst based on its username and a plain password.

    Parameters
    ----------
    username
        the analyst username
    plain_password
        the plain password to check

    Returns
    -------
    bool
        True if the password is associated to the analyst, False otherwise
    """
    conn = get_db_connexion()
    cursor = conn.cursor()

    analyst = db.analysts.get_analyst(username, cursor)
    close_db_connexion(cursor, conn)

    if analyst is None:
        return False  # l'analyst n'existe pas

    hashed = analyst["password"]
    return check_password(password, hashed)


def generate_token(username):
    """Generate a token with a username and an expiracy date of 1h.

    Parameters
    ----------
    username
        the analyst username

    Returns
    -------
    token
        the generated token based on the username and an expiracy date of 1h.
    """
    # Crée le payload du token
    payload = {
        "username": username,
        "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=1)  # expiration 1h
    }

    # Génère le token signé avec la clé secrète et HS256
    token = jwt.encode(payload, SECRET_KEY, algorithm="HS256")

    # jwt.encode peut retourner bytes ou str selon la version de PyJWT
    if isinstance(token, bytes):
        token = token.decode("utf-8")

    return token


def check_token(token):
    """Check the validity of a token.

    Parameters
    ----------
    token
        the token to check

    Returns
    -------
    payload
        The payload associated with the token if the token is correctly decoded.
        An error if the token is expired or invalid
    """
    try:
        # Décode le token avec la clé secrète et l'algorithme HS256
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return payload  # Retourne le payload si tout est correct
    except jwt.ExpiredSignatureError:
        # Le token est expiré
        raise jwt.ExpiredSignatureError("Token has expired")
    except jwt.InvalidTokenError:
        # Le token est invalide
        raise jwt.InvalidTokenError("Token is invalid")


def token_required(f):
    """A decorator to specify which routes need a token validation."""

    @wraps(f)
    def decorated(*args, **kwargs):
        """Define the behaviour of a route when a token validation is required.
        """
        token = None

        if "Authorization" in request.headers:
            token = request.headers["Authorization"].split(" ")[1]

        if not token:
            return jsonify({"message": "Missing token"}), 401

        try:
            payload = check_token(token)
            if not "username" in payload or not "exp" in payload:
                return jsonify({"error": "Invalid token"}), 401

        except jwt.ExpiredSignatureError:
            return jsonify({"error": "Token expired"}), 401
        except jwt.InvalidTokenError:
            return jsonify({"error": "Invalid token"}), 401
        return f(*args, **kwargs)

    return decorated
