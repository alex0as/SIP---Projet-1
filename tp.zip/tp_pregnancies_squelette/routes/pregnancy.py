from flask import Blueprint, jsonify

pregnancies_bp = Blueprint("pregnancies", __name__)


@pregnancies_bp.route("/<int:pregnancy_id>")
def get_pregnancy(pregnancy_id):
    """Get an pregnancy in the database.

    Parameters
    ----------
    pregnancy_id
        id of the pregnancy to get

    Returns
    -------
    data
        all data about the pregnancy if correctly fetched
        a message "pregnancy does not exist" if the pregnancy is not found in
            the database.
        an error message "Error: while fetching the pregnancy" if an error
            occured while fetching the pregnancy.
    status_code
        200 if the pregnancy is correctly fetched
        404 if the pregnancy does not exist in the database
        500 if an error occured while fetching the pregnancy
    """
    # TODO
    return jsonify({"message": "TODO"})


@pregnancies_bp.route("/<int:pregnancy_id>", methods=["PATCH"])
def update_pregnancy(pregnancy_id):
    """Update an pregnancy in the database based on its id.
    The fields to update must be passed in the data of the PATCH request among
    the following (pass any of them):
        - analyst_username
        - registration_date, 
        - registration_time,
        - delivery_date,
        - baby_gender,
        - delivery_type,
        - number_of_checkup_done

    Parameters
    ----------
    pregnancy_id
        id of the pregnancy to update

    Returns
    -------
    data
        a message "Done" if the pregnancy is updated correctly.
        a message "No field provided for update" if no field is found in the
            data passed in the request
        a message "pregnancy does not exist" if the pregnancy is not found in
            the database.
        an error message "Error: while updating the pregnancy" if an error
            occured while updating the pregnancy.
    status_code
        200 if the pregnancy is updated correctly
        400 if no field is found in the data passed in the request
        404 if the pregnancy does not exist in the database
        500 if an error occured while updating the pregnancy
    """
    # TODO
    return jsonify({"message": "TODO"})


@pregnancies_bp.route("/count/")
@pregnancies_bp.route("/count/<int:pregnancy_id>")
def get_hospital_count(pregnancy_id=None):
    """Get the number of hospital following a pregnancy

    Parameters
    ----------
    pregnancy_id
        Id of the pregnancy
            If None, count all pregnancy

    Returns
    -------
    data
        the number of hospital following the pregnancy (or all pregnancies) if correctly fetched
        a message "pregnancy do not exist" if the pregnancy is not found in
            the database.
        an error message "Error: while fetching the pregnancies" if an error
            occured while fetching the pregnancy (or all pregnancies).
    status_code
        200 if the pregnancies are correctly fetched
        404 if the pregnancy does not exist in the database
        500 if an error occured while fetching the pregnancy (or all pregnancies)
    """
    # TODO
    return jsonify({"message": "TODO"})
