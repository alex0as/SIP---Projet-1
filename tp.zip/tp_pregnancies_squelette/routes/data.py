from flask import Blueprint, request, jsonify

data_bp = Blueprint("data", __name__)


@data_bp.route("/pregnancies")
def get_pregnancies():
    """Get all pregnancies in the database.

    Returns
    -------
    data
        all pregnancies in the database
        an error message "Error: while fetching pregnancies" if an error occured
            while fetching the pregnancies.
    status_code
        200 if the pregnancies are correctly fetched
        500 if an error occured while fetching the pregnancies
    """
    # TODO
    return jsonify({"message": "TODO"})


@data_bp.route("/hospitals")
def get_hospitals():
    """Get all hospitals in the database.

    Returns
    -------
    data
        all hospitals in the database
        an error message "Error: while fetching hospitals" if an error occured
            while fetching the hospitals.
    status_code
        200 if the hospitals are correctly fetched
        500 if an error occured while fetching the hospitals
    """
    # TODO
    return jsonify({"message": "TODO"})


@data_bp.route("/checkups")
def get_checkups():
    """Get all checkups in the database.

    Returns
    -------
    data
        all checkups in the database
        an error message "Error: while fetching checkups" if an error occured
            while fetching the checkups.
    status_code
        200 if the checkups are correctly fetched
        500 if an error occured while fetching the checkups
    """
    # TODO
    return jsonify({"message": "TODO"})


@data_bp.route("/women")
def get_women():
    """Get all women in the database.

    Returns
    -------
    data
        all women in the database
        an error message "Error: while fetching women" if an error occured
            while fetching the women.
    status_code
        200 if the women are correctly fetched
        500 if an error occured while fetching the women
    """
    # TODO
    return jsonify({"message": "TODO"})
