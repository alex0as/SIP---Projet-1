from flask import Blueprint, request, jsonify

from db import get_db_connexion, close_db_connexion

import db.analysts

analysts_bp = Blueprint("analysts", __name__)


@analysts_bp.route("/", methods=["GET"])
def get_all_analysts():
    """Fetch all analysts from the database.

    Returns
    -------
    status_code
        200 by default if no error occured
        500 if an error occured while fetching the analysts
    data
        analysts as a json if no error occurs (can be empty if no analysts)
        an error message if an error occured while fetching the analysts.
    """
    conn = get_db_connexion()
    cursor = conn.cursor()

    all_analysts = db.analysts.get_analysts(cursor)
    if all_analysts == None:
        conn.rollback()
        close_db_connexion(cursor, conn)
        return "Error: while fetching analysts", 500
    conn.commit()
    close_db_connexion(cursor, conn)
    return jsonify({"analysts": [dict(analyst)["username"] for analyst in all_analysts]})


@analysts_bp.route("/<analyst_username>", methods=["GET"])
def get_analyst(analyst_username):
    """Fetch a single analyst from the database based on its username.

    Parameters
    ----------
    analyst_username
        username of the analyst (as defined in the database)

    Returns
    -------
    data
        analyst as a json if the analyst is in the database
        an error message "This analyst does not exists" if the analyst requested
            is not in the database
        an error message "Error: while fetching analyst" if an error occured
            while fetching the analyst.
    status_code
        200 if the analyst is correctly fetched
        404 if the query to the database was a success but the analyst
                is not in the database
        500 if an error occured while fetching the analyst
    """
    # TODO
    return jsonify({"message": "TODO"})


@analysts_bp.route("/<analyst_username>", methods=["PATCH"])
def patch_password(analyst_username):
    """Patch the password of an analyst.
    The password must be passed in the data of the POST request.

    Parameters
    ----------
    analyst_username
        username of the analyst (as defined in the database)

    Returns
    -------
    data
        analyst as a json if the analyst is in the database
        a message "Password not provided" if the password is not in
            the request
        an error message "Error: while updating password" if an error
            occured while updating the password.
    status_code
        200 if the password is correctly modified
        404 if no password is provided in the request
        500 if an error occured while updating the password
    """
    # TODO
    return jsonify({"message": "TODO"})


@analysts_bp.route("/", methods=["POST"])
def add_analyst():
    """Add an analyst to the database.
    The username and password must be passed in the data of the POST request.

    Returns
    -------
    data
        a message "Done" if the analyst is correctly added
        a message "Username or password not provided" if the password or
            username is not in the data of the POST request
        an error message "Error: while adding a new analyst" if an error occured
            while updating the password
    status_code
        200 if the analyst was added to the database
        404 if no username and password are provided in the request
        500 if an error occured while updating the password
    """
    # TODO
    return jsonify({"message": "TODO"})
