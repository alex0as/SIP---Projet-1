def insert_woman(code, name, age, birth, blood_type, insurance_id):
    # TODO
    pass


def get_woman(woman_id):
    # TODO
    pass


def get_women():
    # TODO
    pass
