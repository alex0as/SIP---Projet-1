def insert_checkup(code, data, time, weight, blood_pressure_category, maternal_mental_health, gestional_age, fetal_heart_rate, anomaly):
    # TODO
    pass

def get_checkup(id):
    # TODO
    pass

def get_checkups():
    # TODO
    pass
