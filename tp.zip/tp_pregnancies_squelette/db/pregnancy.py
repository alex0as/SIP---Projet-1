def insert_pregnancy(
    id,
    registration_date, 
    registration_time,
    delivery_date,
    baby_gender,
    delivery_type,
    number_of_checkup_done,
    woman_code,
    analyst_name,
):
    # TODO
    pass


def get_pregnancies():
    # TODO
    pass


def get_pregnancy(id):
    # TODO
    pass

def get_involved_woman(id):
    # TODO
    pass

def insert_hospital_pregnancy(id, hospital_id):
    # TODO
    pass

def update_hospital_pregnancy(id, hospital_id):
    # TODO
    pass

def get_hospital_pregnancy(id, hospital_id):
    # TODO
    pass

def update_pregnancy_delivery_type(id, delivety_type):
    # TODO
    pass


def update_pregnancy_woman(id, woman_id):
    # TODO
    pass
