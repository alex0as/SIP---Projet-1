def insert_hospital(code, name):
    # TODO
    pass

def get_hospital(hospital_id):
    # TODO
    pass

def get_hospitals():
    # TODO
    pass
