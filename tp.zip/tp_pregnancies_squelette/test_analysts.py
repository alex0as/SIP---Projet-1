import db.analysts
from db import get_db_connexion, close_db_connexion


def print_analysts():
    """Print the analysts in the database in the console."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    analysts = db.analysts.get_analysts(cursor)
    print("analysts in database:", [dict(analyst)
          for analyst in analysts])

    close_db_connexion(cursor, conn)


def insert_hubert(cursor):
    """Inserts a analyst into the database.

    Parameters
    ----------
    cursor:
        The object used to query the database.

    Returns
    -------
    bool
        True if the analyst could be inserted, False otherwise.
    """

    # Personal data of analyst Hubert
    hubert = {"username": "hubert", "password": "117"}

    print("Inserting analyst Hubert...")
    if db.analysts.insert_analyst(hubert, cursor):
        print("Hubert added successfully !")
        return True
    else:
        print("Impossible to add Hubert ...")
        return False


########## TEST FUNCTIONS ##########


def test_insert_analyst():
    print("## TEST: insert a analyst")
    # Open a connexion to the database.
    conn = get_db_connexion()

    # Get the cursor for the connection. This object is used to execute queries
    # in the database.
    cursor = conn.cursor()

    # Insert analyst Hubert
    insert_hubert(cursor)

    # Close connexion
    close_db_connexion(cursor, conn)


def test_update_password_existing_analyst():
    print("\n## TEST: update a analyst that is in the database")
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        # Update analyst hubert
        update_ok = db.analysts.update_password("hubert", "12", cursor)

        # Print results from update
        print("Update successful:", update_ok)
        print("Number of modified rows in the database:", cursor.rowcount)
    except NotImplementedError as error:
        print("update_password() not implemented")
    close_db_connexion(cursor, conn)


def test_update_password_non_existing_analyst():
    print("\n## TEST: update a analyst that does not exist in the database")
    conn = get_db_connexion()
    cursor = conn.cursor()

    # Update analyst bond
    try:
        update_ok = db.analysts.update_password("bond", "12", cursor)
        # Print results from update
        print("Update successful:", update_ok)
        print("Number of modified rows in the database:", cursor.rowcount)
    except NotImplementedError as error:
        print("update_password() not implemented")

    close_db_connexion(cursor, conn)


if __name__ == "__main__":

    test_insert_analyst()
    print_analysts()

    # test_update_password_existing_analyst()
    # test_update_password_non_existing_analyst()
    # print_analysts()
