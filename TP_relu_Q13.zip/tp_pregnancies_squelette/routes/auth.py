from flask import Blueprint, request, jsonify
from utils import check_analyst, check_token, generate_token

auth_bp = Blueprint("login", __name__)


@auth_bp.route("/login", methods=["POST"])
def login():
    """Login a analyst and provide a token for future requests to the API

    Returns
    -------
    data
        a token to authenticate future request to the API.
        an error message "No username or password provided" if the
            username or password is not provided
        an error message "Error: while authenticating analyst" if an error
            occured while authenticating the analyst.
    status_code
        200 if the token is correctly provided
        400 if the username or password is not provided
        500 if an error occured while authenticating the analyst
    """
    try:
        # Récupérer les données envoyées par le client en JSON
        data = request.get_json()
        username = data.get("username")
        password = data.get("password")

        # Vérifier que username et password sont fournis
        if not username or not password:
            return jsonify({"error": "No username or password provided"}), 400

        # Vérifier si l'analyst existe et si le mot de passe est correct
        if check_analyst(username, password):
            # Générer un token JWT
            token = generate_token(username)
            return jsonify({"token": token}), 200
        else:
            # Identifiant ou mot de passe incorrect
            return jsonify({"error": "Invalid credentials"}), 401

    except Exception as e:
        # Gestion d'erreurs génériques
        return jsonify({"error": f"Error: while authenticating analyst ({str(e)})"}), 500
