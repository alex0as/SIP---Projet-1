from flask import Blueprint, request, jsonify

from db import get_db_connexion, close_db_connexion

import db.analysts

analysts_bp = Blueprint("analysts", __name__)


@analysts_bp.route("/", methods=["GET"])
@token_required #question 24
def get_all_analysts():
    """Fetch all analysts from the database.

    Returns
    -------
    status_code
        200 by default if no error occured
        500 if an error occured while fetching the analysts
    data
        analysts as a json if no error occurs (can be empty if no analysts)
        an error message if an error occured while fetching the analysts.
    """
    conn = get_db_connexion()
    cursor = conn.cursor()

    all_analysts = db.analysts.get_analysts(cursor)
    if all_analysts == None:
        conn.rollback()
        close_db_connexion(cursor, conn)
        return "Error: while fetching analysts", 500
    conn.commit()
    close_db_connexion(cursor, conn)
    return jsonify({"analysts": [dict(analyst)["username"] for analyst in all_analysts]})


@analysts_bp.route("/<analyst_username>", methods=["GET"])
@token_required #question 24
def get_analyst(analyst_username):
    """Fetch a single analyst from the database based on its username.

    Parameters
    ----------
    analyst_username
        username of the analyst (as defined in the database)

    Returns
    -------
    data
        analyst as a json if the analyst is in the database
        an error message "This analyst does not exists" if the analyst requested
            is not in the database
        an error message "Error: while fetching analyst" if an error occured
            while fetching the analyst.
    status_code
        200 if the analyst is correctly fetched
        404 if the query to the database was a success but the analyst
                is not in the database
        500 if an error occured while fetching the analyst
    """
    conn = get_db_connexion()
    cursor = conn.cursor()

    analyst = db.analysts.get_analyst(analyst_username, cursor)

    if analyst is None:
        close_db_connexion(cursor, conn)
        return jsonify({"error": "This analyst does not exist"}), 404

    close_db_connexion(cursor, conn)
    return jsonify(analyst), 200

@analysts_bp.route("/<analyst_username>", methods=["PATCH"])
@token_required #question 24
def patch_password(analyst_username):
    """Patch the password of an analyst.
    The password must be passed in the data of the POST request.

    Parameters
    ----------
    analyst_username
        username of the analyst (as defined in the database)

    Returns
    -------
    data
        analyst as a json if the analyst is in the database
        a message "Password not provided" if the password is not in
            the request
        an error message "Error: while updating password" if an error
            occured while updating the password.
    status_code
        200 if the password is correctly modified
        404 if no password is provided in the request
        500 if an error occured while updating the password
    """
    conn = get_db_connexion()
    cursor = conn.cursor()

    data = request.get_json()

    # Vérifier que le champ "password" est bien fourni
    if not data or "password" not in data:
        return jsonify({"error": "Password not provided"}), 400

    # Mettre à jour le mot de passe
    success = db.analysts.update_password(analyst_username, data["password"], cursor)
    conn.commit()
    close_db_connexion(cursor, conn)

    # Vérifier si la mise à jour a réussi
    if success:
        return jsonify({"message": "Password updated successfully"}), 200
    else:
        return jsonify({"error": "Analyst not found"}), 404


@analysts_bp.route("/", methods=["POST"])
@token_required #question 24
def add_analyst():
    """Add an analyst to the database.
    The username and password must be passed in the data of the POST request.

    Returns
    -------
    data
        a message "Done" if the analyst is correctly added
        a message "Username or password not provided" if the password or
            username is not in the data of the POST request
        an error message "Error: while adding a new analyst" if an error occured
            while updating the password
    status_code
        200 if the analyst was added to the database
        404 if no username and password are provided in the request
        500 if an error occured while updating the password
    """
    conn = get_db_connexion()
    cursor = conn.cursor()

    # Récupérer les données JSON envoyées
    data = request.get_json()

    # Vérifier que username et password sont fournis
    if not data or "username" not in data or "password" not in data:
        close_db_connexion(cursor, conn)
        return jsonify({"error": "Username or password not provided"}), 400

    # Essayer d'insérer l'analyst
    success = db.analysts.insert_analyst(data, cursor)
    conn.commit()
    close_db_connexion(cursor, conn)

    # Retour selon le résultat
    if success:
        return jsonify({"message": "Analyst added successfully"}), 200
    else:
        return jsonify({"error": "Could not add analyst (maybe already exists)"}), 500  
