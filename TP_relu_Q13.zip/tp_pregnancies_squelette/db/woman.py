def insert_woman(code, name, age, birth, blood_type, insurance_id):
    """Insert a new woman into the database."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        query = """
        INSERT INTO Woman (code, name, age, birth, blood_type, insurance_id)
        VALUES (?, ?, ?, ?, ?, ?)
        """
        cursor.execute(query, (code, name, age, birth, blood_type, insurance_id))
        conn.commit()
    except sqlite3.IntegrityError as error:
        print(f"Integrity error while inserting woman: {error}")
        close_db_connexion(cursor, conn)
        return False
    except sqlite3.Error as error:
        print(f"Database error while inserting woman: {error}")
        close_db_connexion(cursor, conn)
        return False

    close_db_connexion(cursor, conn)
    return True


def get_woman(woman_id):
    """Get a woman by her code or ID."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        query = "SELECT * FROM Woman WHERE code = ?"
        cursor.execute(query, (woman_id,))
        woman = cursor.fetchone()
    except sqlite3.Error as error:
        print(f"Database error while fetching woman: {error}")
        close_db_connexion(cursor, conn)
        return None

    close_db_connexion(cursor, conn)
    return woman


def get_women():
    """Get all women from the database."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        query = "SELECT * FROM Woman"
        cursor.execute(query)
        women = cursor.fetchall()
    except sqlite3.Error as error:
        print(f"Database error while fetching women: {error}")
        close_db_connexion(cursor, conn)
        return None

    close_db_connexion(cursor, conn)
    return women
