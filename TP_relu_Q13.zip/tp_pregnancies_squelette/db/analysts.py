import utils
import sqlite3
from utils import hash_password

def insert_analyst(analyst, cursor):
    """Inserts a analyst into to the database.

    Parameters
    ----------
    analyst: a dictionnary
        analyst personal data: analyst["username"] and analyst["password"].
    cursor:
        The object used to query the database.

    Returns
    -------
    bool
        True if no error occurs, False otherwise.
    """
    try:
        # The analyst is described by two attributes: username and password.
        # The values of these attributes are available in the dictionary analyst, one of the parameters of this function.
        # So, we need to write our insert query in such a way that the values are obtained from the dictionary analyst.
        # Our insert query contains two question marks (?) that indicate that the values will be specified later.
        #
        #  IMPORTANT:
        #
        # * The query assumes that you called analyst the table with the analyst personal data. If you gave it another name, CHANGE the query accordingly.
        #
        # * The query assumes that in your table analyst the columns are defined in this order:
        # username, password.
        # IF THE ORDER in which you created the columns IS DIFFERENT, CHANGE this variable accordingly.

        # Hasher le mot de passe avant insertion
        hashed_password = hash_password(analyst["password"])
        
        query_insert_analyst = "INSERT INTO Analyst (username, password) VALUES (?, ?)"
        cursor.execute(query_insert_analyst,
                       (analyst["username"], hashed_password))
        cursor.connection.commit()
    except sqlite3.IntegrityError as error:
        print(
            f"An integrity error occurred while insert the analyst: {error}")
        return False
    except sqlite3.Error as error:
        print(
            f"A database error occurred while inserting the analyst: {error}")
        return False

    return True


def get_analyst(username, cursor):
    """Get a analyst from the database based on its username and a list of
    the tickets bought by the analyst.

    Parameters
    ----------
    username: string
        analyst username.
    cursor:
        The object used to query the database.

    Returns
    -------
    dict
        The analyst username, password and tickets if no error occurs, None otherwise.
    """
    try:
        query_get_analyst = "SELECT * FROM analyst WHERE username = ?"
        cursor.execute(query_get_analyst, [username])

        analyst = cursor.fetchone()

        query_get_tickets = "SELECT id FROM Tickets WHERE analyst_username = ?"
        cursor.execute(query_get_tickets, [username])

        tickets = cursor.fetchall()

    except sqlite3.IntegrityError as error:
        print(
            f"An integrity error occurred while fetching the analyst: {error}")
        return None
    except sqlite3.Error as error:
        print(
            f"A database error occurred while fetching the analyst: {error}")
        return None

    return {
        "username": analyst["username"],
        "tickets": tickets,
        "password": analyst["password"],
    }


def get_analysts(cursor):
    """Get all analysts from the database.

    Parameters
    ----------
    cursor:
        The object used to query the database.

    Returns
    -------
    list
        The list of all the analyst if no error occurs, None otherwise.
    """
    try:
        query_get_analysts = "SELECT username FROM analyst"
        cursor.execute(query_get_analysts, [])

    except sqlite3.IntegrityError as error:
        print(
            f"An integrity error occurred while fetching the analysts: {error}")
        return None
    except sqlite3.Error as error:
        print(
            f"A database error occurred while fetching the analysts: {error}")
        return None

    return cursor.fetchall()


def update_password(username, password, cursor):
    """Update the password of an analyst.

    Parameters
    ----------
    username: string
        Analyst username.
    password: bytes
        New password.
    cursor:
        The object used to query the database.

    Returns
    -------
    bool
        True if no error occurs, False otherwise.
    """
    try:
        query_update = "UPDATE Analyst SET password = ? WHERE username = ?"
        cursor.execute(query_update, (password, username))

        # Check whether any row was updated
        if cursor.rowcount == 0:
            print(f"No analyst found with username '{username}'.")
            return False

        # Commit the transaction
        cursor.connection.commit()

    except sqlite3.IntegrityError as error:
        print(f"An integrity error occurred while updating password: {error}")
        return False
    except sqlite3.Error as error:
        print(f"A database error occurred while updating password: {error}")
        return False

    return True

