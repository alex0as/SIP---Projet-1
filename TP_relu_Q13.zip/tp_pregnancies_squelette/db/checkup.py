def insert_checkup(
    code, 
    date, 
    time, 
    weight, 
    blood_pressure_category, 
    maternal_mental_health, 
    gestional_age, 
    fetal_heart_rate, 
    anomaly
):
    """Insert a new checkup into the database."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        query = """
        INSERT INTO Checkup (
            code, date, time, weight, blood_pressure_category,
            maternal_mental_health, gestional_age, fetal_heart_rate, anomaly
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        cursor.execute(query, (
            code,
            date,
            time,
            weight,
            blood_pressure_category,
            maternal_mental_health,
            gestional_age,
            fetal_heart_rate,
            anomaly
        ))
        conn.commit()
    except sqlite3.IntegrityError as error:
        print(f"Integrity error while inserting checkup: {error}")
        close_db_connexion(cursor, conn)
        return False
    except sqlite3.Error as error:
        print(f"Database error while inserting checkup: {error}")
        close_db_connexion(cursor, conn)
        return False

    close_db_connexion(cursor, conn)
    return True


def get_checkup(code):
    """Get a single checkup by its code."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT * FROM Checkup WHERE code = ?", (code,))
        checkup = cursor.fetchone()
    except sqlite3.Error as error:
        print(f"Database error while getting checkup: {error}")
        close_db_connexion(cursor, conn)
        return None

    close_db_connexion(cursor, conn)
    return checkup


def get_checkups():
    """Get all checkups from the database."""
    conn = get_db_connexion()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT * FROM Checkup")
        checkups = cursor.fetchall()
    except sqlite3.Error as error:
        print(f"Database error while getting checkups: {error}")
        close_db_connexion(cursor, conn)
        return None

    close_db_connexion(cursor, conn)
    return checkups
